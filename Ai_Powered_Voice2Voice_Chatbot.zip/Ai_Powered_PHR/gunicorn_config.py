workers = 4
bind = "0.0.0.0:4018"
chdir = "/usr/src/app/"
module = "app.wsgi:application"
timeout = 120