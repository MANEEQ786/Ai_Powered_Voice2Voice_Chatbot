from django.apps import AppConfig


class PhrAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'voice_phr'
